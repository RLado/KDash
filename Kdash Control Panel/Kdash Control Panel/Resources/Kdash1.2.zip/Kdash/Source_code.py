import win32api
import win32console
import win32gui
import pythoncom,pyHook
import pyautogui
import threading
from time import sleep

print('Welcome to kdash')
win=win32console.GetConsoleWindow()
win32gui.ShowWindow(win,0)
#Open config file
try:
    f=open('kdash.conf','r')
    filecontent=f.read()
    f.close()
#If open fails its the first time. Run setup config file and exit
except:
    print('Running setup sequence')
    f=open('kdash.conf','w')
    f.write('''Welcome to kdash config file:
To assign a macro to a key write $xxx=[Code], where xxx is the 3 number KeyID
i.e. $113=Hello World [Add € to press enter]
A wait time in sec. can be added by using |X| i.e. |0.5|
Set keypress interval:
%%0.025
===============================================''')
    f.close()
    exit()
for i in filecontent.split('\n'):
    if i[:2]=='%%':
        waitint=float(i[2:])
        break
def out_key(strin):
    if '€' in strin:
        for i in strin.split('€'):
            pyautogui.typewrite(i,interval=waitint)
            if i!=strin.split('€')[-1]:
                pyautogui.press('enter')
    else:
        pyautogui.typewrite(strin,interval=waitint)
        
def add_wait(strin): #adds a user defined wait in the middle of a out_key call.
    for i in strin.split('|'):
        try: #Check for a float
            sleep(float(i))
        except:
            out_key(i)
            
def OnKeyboardEvent(event):
    #lets parse the config file
    for i in filecontent.split('\n'): #split the file
        if len(i)>1:
            if i[0]== '$': #Ignore comment lines
                key = event.KeyID
                if key == int(i[1:4]):
                    kout=str(i[5:])
                    t1=threading.Thread(target=add_wait,args=(kout,))
                    t1.start()
    return 1
    
# create a hook manager object
hm=pyHook.HookManager()
hm.KeyDown=OnKeyboardEvent
# set the hook
hm.HookKeyboard()
# wait forever
pythoncom.PumpMessages()
